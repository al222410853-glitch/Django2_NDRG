# Web Personal del Curso de Django

Proyecto revisado y funcionando perfectamente con Python 3.10.2 y Django 4.0.2

## Instalación con Pipenv

```bash
pipenv install
```

## Instalación sin Pipenv

```bash
pip install -r requirements.txt
```